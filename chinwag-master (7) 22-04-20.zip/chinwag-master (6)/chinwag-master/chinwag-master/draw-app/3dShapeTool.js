function drawShapeTool(){
  var previousMouseX = -1;
  var previousMouseY = -1;
  var rectArr = []
  this.icon = "assets/square.png";
  this.name = "3d square";

  this.draw = function(){



    if (mouseIsPressed){
      beginShape();
      fill(0);
      ellipse(mouseX,mouseY,50,50);

      // rect(mouseX,mouseY,30,30);

      endShape();
    }

    // if(mouseIsPressed){
    //   if(previousMouseX == -1)
    //  {
    //    previousMouseX = mouseX;
    //    previousMouseY = mouseY;
    // }

    // else {
    //   updatePixels();
    //
    //
    //   rectArr.push({
    //     x:previousMouseX,
    //     y:previousMouseY,
    //     newX:mouseX,
    //     newY:mouseY
    //     }
    //     );
    //
    //     beginShape();
    //     rect(rectArr.x,rectArr.Y,rectArr.newX,rectArr.newY);
    //     endShape();
    //
    // }
  }
}
