# Drawing-Application
A drawing app as our uni coursework. 

Aim:

    1. Draw shapes via shape tool.
    2. Adjustable thickness of pen tool.
    3. Zooming in and out button
    4. Eraser tool
    5. Add shapes (rotate shapes)
    6. undo button

currently, thickness tool is in the making, we have started to make steps to fully completing.

Adding & rotating shape function, we have started this (this will essentially be the vertex tool)

we have also made progress eraser tool. once selected you can hold the mouse and drag over any drawing to remove it.    
